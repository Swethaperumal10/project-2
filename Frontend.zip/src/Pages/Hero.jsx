import React from 'react'

export default function Hero() {
  return (
    <div>
        <img src="https://startuptn.in/images/Banner/Thiruvizha%20Web%20Banner%20(5).png" width="300%"/>
    </div>
  )
}
